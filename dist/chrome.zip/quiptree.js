function Storage() {
  var cache = this.cache = {}
  chrome.storage.onChanged.addListener(function(changes) {
    for (var key in changes) cache[key] = changes[key].newValue
  })
}

Storage.prototype.set = function(key, val, local, cb) {
  if (typeof local === 'function') {
    cb = local
    local = false
  }

  cb = cb || Function()
  this.cache[key] = val

  if (local) {
    localStorage.setItem(key, JSON.stringify(val))
    cb()
  }
  else {
    var item = {}
    item[key] = val
    chrome.storage.local.set(item, cb)
  }
}

Storage.prototype.get = function(key, local, cb) {
  if (typeof local === 'function') {
    cb = local
    local = false
  }

  if (!cb) return this.cache[key]

  if (local) cb(parse(localStorage.getItem(key)))
  else chrome.storage.local.get(key, function(item) {
    cb(item[key])
  })

  function parse(val) {
    try {
      return JSON.parse(val)
    } catch (e) {
      return val
    }
  }
}
const TEMPLATE = '<div>\n' +
    '  <div class="quiptree_sidebar ui-widget-content">\n' +
    '    <div class="quiptree_views">\n' +
    '      <div class="quiptree_view quiptree_treeview current">\n' +
    '        <div class="quiptree_view_header">\n' +
    '          <a class="quiptree_opts" href="javascript:void(0)"><span></span></a>\n' +
    '          <span class="quiptree_header_icon"></span>\n' +
    '          <input type="text" placeholder="Search" value="" class="input">\n' +
    '        </div>\n' +
    '        <div class="quiptree_view_body"></div>\n' +
    '      </div>\n' +
    '\n' +
    '      <div class="quiptree_view quiptree_errorview">\n' +
    '        <div class="quiptree_view_header">\n' +
    '          <span class="quiptree_header_icon">Oops</span>\n' +
    '        </div>\n' +
    '        <form class="quiptree_view_body">\n' +
    '          <div class="message"></div>\n' +
    '          <div>\n' +
    '            <input name="token" type="text" placeholder="Paste access token here" autocomplete="off">\n' +
    '          </div>\n' +
    '          <div>\n' +
    '            <button type="submit" class="btn">Save</button>\n' +
    '            <a href="https://quip.com/api/personal-token" target="_blank" tabIndex="-1">Create one now</a>\n' +
    '          </div>\n' +
    '          <div class="error"></div>\n' +
    '        </form>\n' +
    '      </div>\n' +
    '\n' +
    '      <div class="quiptree_view quiptree_optsview">\n' +
    '        <div class="quiptree_view_header">\n' +
    '          <a class="quiptree_opts" href="javascript:void(0)"><span></span></a>\n' +
    '          <span class="quiptree_header_icon">Settings</span>\n' +
    '        </div>\n' +
    '        <form class="quiptree_view_body">\n' +
    '          <div>\n' +
    '            <div style=\'margin-bottom: 10px\'>\n' +
    '              <label>Quip access token</label>\n' +
    '              <a href="https://quip.com/api/personal-token" target="_blank" tabIndex="-1">Create one now</a>\n' +
    '            </div>\n' +
    '            <input type="text" data-store="TOKEN" data-perhost="true">\n' +
    '          </div>\n' +
    '          <hr />\n' +
    '          <div>\n' +
    '            <label><input type="checkbox" data-store="REMEMBER">Show sidebar if previously shown</label>\n' +
    '          </div>\n' +
    '          <div>\n' +
    '            <label><input type="checkbox" data-store="LAZYLOAD">Only load tree when sidebar is open</label>\n' +
    '          </div>\n' +
    '          <div>\n' +
    '            <label><input type="checkbox" data-store="STATES">Saves the state of the tree (selected folders, opened folders)</label>\n' +
    '          </div>\n' +
    '          <div>\n' +
    '            <div style=\'margin-bottom: 10px\'>\n' +
    '              <label>Hotkeys</label>\n' +
    '              <a href="https://github.com/madrobby/keymaster#defining-shortcuts" target="_blank" tabIndex="-1">Supported keys</a>\n' +
    '            </div>\n' +
    '            <input type="text" data-store="HOTKEYS">\n' +
    '          </div>\n' +
    '          <div>\n' +
    '            <button type="submit" class="btn">Save</button>\n' +
    '          </div>\n' +
    '        </form>\n' +
    '      </div>\n' +
    '    </div>\n' +
    '  </div>\n' +
    '\n' +
    '  <div class="quiptree_popup">\n' +
    '    <div class="arrow"></div>\n' +
    '    <div class="content">\n' +
    '      Quiptree is enabled on Quip pages. Click this button or press\n' +
    '\n' +
    '      <kbd>cmd shift s</kbd> (or <kbd>ctrl shift s</kbd>)\n' +
    '      to show it.\n' +
    '    </div>\n' +
    '  </div>\n' +
    '</div>\n' +
    ''
const
    PREFIX = 'quiptree'

  , STORE = {
    TOKEN    : 'quiptree.quip_access_token',
    STATES   : 'quiptree.states',
    REMEMBER : 'quiptree.remember',
    LAZYLOAD : 'quiptree.lazyload',
    HOTKEYS  : 'quiptree.hotkeys',
    WIDTH    : 'quiptree.sidebar_width',
    POPUP    : 'quiptree.popup_shown',
    SHOWN    : 'quiptree.sidebar_shown'
  }

  , DEFAULTS = {
    TOKEN    : '',
    REMEMBER : false,
    STATES : true,
    LAZYLOAD : false,
    HOTKEYS  : '⌘+⇧+s, ⌃+⇧+s',
    WIDTH    : 253,
    POPUP    : false,
    SHOWN    : false
  }

  , EVENT = {
    TOGGLE        : 'quiptree:toggle',
    LOC_CHANGE    : 'quiptree:location',
    LAYOUT_CHANGE : 'quiptree:layout',
    REQ_START     : 'quiptree:start',
    REQ_END       : 'quiptree:end',
    OPTS_CHANGE   : 'quiptree:change',
    VIEW_READY    : 'quiptree:ready',
    VIEW_CLOSE    : 'quiptree:close'
  }

const
  QUIP_CONTAINERS = 'article, .body.scrollable'
  QUIP_IGNORE_PAGES = [/.*api.*/i, /.*account.*/i, /.*about.*/i, /.*blog.*/i, /.*business.*/i]

function Quip() {
  if (!window.MutationObserver) return

  // Fix #151 by detecting when page layout is updated.
  // In this case, split-diff page has a wider layout, so need to recompute margin.
  var observer = new window.MutationObserver(function(mutations) {
    for (var i = 0, len = mutations.length; i < len; i++) {
      var mutation = mutations[i]
      if (~mutation.oldValue.indexOf('split-diff') ||
          ~mutation.target.className.indexOf('split-diff')) {
        return $(document).trigger(EVENT.LAYOUT_CHANGE)
      }
    }
  })

  observer.observe(document.body, {
    attributes: true,
    attributeFilter: ['class'],
    attributeOldValue: true
  })
}

/**
 * Updates page layout based on visibility status and width of the Quiptree sidebar.
 */
Quip.prototype.updateLayout = function(sidebarVisible, sidebarWidth) {
  var $containers = $(QUIP_CONTAINERS)
   , spacing = 10
  $containers.stop().animate({'margin-right': sidebarVisible ? sidebarWidth - spacing : ''}, 'fast')
}

/**
 * Ignore to load extension on some pages.
 */
Quip.prototype.canLoadExtension = function() {

  for (var i = 0; i < QUIP_IGNORE_PAGES.length; i++) {
    var pattern = QUIP_IGNORE_PAGES[i]
    if (window.location.pathname.search(pattern) ==! -1)
      return false
    else if ($('footer').length && $('footer').html().search(pattern) ==! -1) // For quip.com homepage
      return false
  }
  return true
}


/**
 * Init Quip Api.
 * @param token(required) user access token
 * @param reload(required) reload quip object with new token
 * @param callback(quipApi: Quip Api object)
 */
Quip.prototype.initQuipApi = function(token, reload, callback) {

  var self = this
    , quipApi

  if (typeof self.quipApi === 'undefined' || reload === true)
  {
    var QuipApi = require('quip.Quip')

    try {
      self.quipApi = new QuipApi({accessToken: token})
      callback(null, self.quipApi)
    }
    catch (error) {
      callback(error)
    }
  }
  else {
    callback(null, self.quipApi)
  }

}

/**
 * Set Root Folder Id.
 * @param rootFolderId(required) set root folder id

 */
Quip.prototype.setRootFolderId = function(rootFolderId) {
  this.rootFolderId = rootFolderId
}

/**
 * Set User Id.
 * @param userId(required) set user id

 */
Quip.prototype.setUserId = function(userId) {
  this.userId = userId
}

/**
 * Fetches authenticated user.
 * @param token(required) user access token
 * @param reload(required) reload quip object with new token
 * @param callback(err: error, user: user object, alreadyAuthenticated: boolean)
 */
Quip.prototype.fetchAuthenticatedUser = function(token, reload, callback) {

  var self = this

  if (typeof self.user === 'undefined' || reload === true) {

    this.initQuipApi(token, reload, function(error, quipApi) {

      if (error) return callback(error)

      quipApi.usr.getAuthenticatedUser(function(error, user) {
        if (error) return callback(error)
        self.user = user
        callback(null, user, false)
      })

    })
  }
  else {
    callback(null, self.user, true)
  }

}

/**
 * Fetches tree.
 * @param token(required) user access token
 * @param parentFolderId(required) parent folder id
 * @param reload(required) reload quip object with new token
 * @param callback(err: error, tree: array (of arrays) of items)
 */
Quip.prototype.fetchData = function(token, parentFolderId, reload, callback) {

  var self = this

  this.initQuipApi(token, reload, function(error, quipApi) {

    if (error) return callback(error)
    parentFolderId = (parentFolderId === '#') ? self.rootFolderId : parentFolderId
    self.fetchTree(quipApi, parentFolderId, function(error, folders) {
      if (error) return callback(error)
      return callback(null, folders)
    })

  })

}

/**
 * Create a Folder Item.
 * @param folder(required) folder object
 * @param callback(item: folder item)
 */
Quip.prototype.createFolderItem = function(folder, callback)
{
  var item = new Object()
  item.id = (folder.id === this.rootFolderId) ? '#' : folder.id
  item.children = true
  item.li_attr = new Object()
  item.li_attr['data-color'] = folder.color ? 'color-' + folder.color : 'color-manila'
  item.li_attr['data-link-id'] = folder.id
  item.text = folder.title ? folder.title : 'Desktop'
  item.icon = 'tree'
  item.type = 'tree'
  callback(item)
}

/**
 * Create a Thread Item.
 * @param thread(required) thread object
 * @param callback(item: thread item)
 */
Quip.prototype.createThreadItem = function(thread, callback)
{
  var item = new Object()
  item.id = thread.id
  item.children = false
  item.a_attr = new Object()
  item.a_attr['data-click'] = 'open-document'
  item.a_attr['data-title'] = thread.title
  item.a_attr['data-id'] = thread.id
  item.a_attr['data-thread-id'] = thread.id
  item.a_attr['data-link-id'] = thread.link.split('/').pop()
  item.text = thread.title
  item.icon = 'blob'
  item.type = 'blob'
  callback(item)
}

/**
 * Fetches threads.
 * @param quipApi(required) quipApi Object
 * @param threadsIds(required) array of threads ids
 * @param callback(err: error, tree: array (of arrays) of items)
 */
Quip.prototype.fetchThreads = function(quipApi, threadsIds) {

  var self = this
    , threads = []
    , dfd = $.Deferred()

  if (threadsIds.length === 0) return dfd.resolve(threads)

  quipApi.th.getThreads({ids: threadsIds}, function(error, data) {

    Object.keys(data).forEach(function(key, index) {
      thread = data[key].thread
      self.createThreadItem(thread, function(item) {
        threads.push(item)
        if (index == Object.keys(data).length - 1) dfd.resolve(threads)
      })
    })
  })

  return dfd.promise()
}

/**
 * Fetches folders.
 * @param quipApi(required) quipApi Object
 * @param foldersIds(required) array of folders ids
 * @param callback(err: error, tree: array (of arrays) of items)
 */
Quip.prototype.fetchFolders = function(quipApi, foldersIds) {

  var self = this
    , folders = []
    , dfd = $.Deferred()

  if (foldersIds.length === 0) return dfd.resolve(folders)

  quipApi.fdr.getFolders({ids: foldersIds}, function(error, data) {

    Object.keys(data).forEach(function(key, index) {
      folder = data[key].folder
      self.createFolderItem(folder, function(item) {
        folders.push(item)
        if (index == Object.keys(data).length - 1) dfd.resolve(folders)
      })
    })

  })

  return dfd.promise()
}

/**
 * Fetches tree.
 * @param quipApi(required) quipApi Object
 * @param parentFolderId(required) array of folders ids
 * @param callback(err: error, tree: array (of arrays) of items)
 */
Quip.prototype.fetchTree = function(quipApi, parentFolderId, callback) {

  var self = this

  quipApi.fdr.getFolder({id: parentFolderId}, function(error, folder) {
    if (error) return callback(error)

    childrenThreads = folder.children.filter(function(obj) {
      return (obj.hasOwnProperty('thread_id'))
    })

    childrenFolders = folder.children.filter(function(obj) {
      return (obj.hasOwnProperty('folder_id') && !obj.hasOwnProperty('restricted'))
    })

    threadsIds = childrenThreads.map(function(obj) {
      return obj.thread_id
    })

    foldersIds = childrenFolders.map(function(obj) {
      return obj.folder_id
    })

    d1 = self.fetchThreads(quipApi, threadsIds)
    d2 = self.fetchFolders(quipApi, foldersIds)

    $.when(d1, d2).done(function(v1, v2) {
      callback(null, $.merge(v1, v2))
    })

  })

}

function HelpPopup($dom, store) {
  this.$view = $dom.find('.quiptree_popup')
  this.store = store
}

HelpPopup.prototype.show = function() {
  var $view = this.$view
    , store = this.store
    , popupShown = store.get(STORE.POPUP)

  if (popupShown) return

  // Hack to show popup hover search bar for small screen.
  if ( $('.full-text-search-box.popover-anchor').length )
    $('.full-text-search-box.popover-anchor').css('z-index', 1)

  $view.css('display', 'block').appendTo($('body'))

  $(document).one(EVENT.TOGGLE, hide)
  setTimeout(function() {
    store.set(STORE.POPUP, true)
    $view.addClass('show').click(hide)
    setTimeout(hide, 6000)
  }, 500)

  function hide() {
    if ($view.hasClass('show')) {
      $view.removeClass('show').one('transitionend', function() { $view.remove() })
    }
  }
}
function ErrorView($dom, store) {
  var self = this
  this.$view = $dom.find('.quiptree_errorview').submit(saveToken)
  this.store = store

  function saveToken(event) {
    event.preventDefault()
    var $view = self.$view
      , $error = $view.find('.error').text('')
      , $token = $view.find('[name="token"]')
      , oldToken = store.get(STORE.TOKEN, true)
      , newToken = $token.val()

    if (!newToken) return $error.text('Token is required')

    store.set(STORE.TOKEN, newToken, true, function() {
      var changes = {}
      changes[STORE.TOKEN] = [oldToken, newToken]
      $(self).trigger(EVENT.OPTS_CHANGE, changes)
      $token.val('')
    })
  }
}

ErrorView.prototype.show = function(err) {
  var self = this
    , $view = this.$view
    , $token = $view.find('input[name="token"]')
    , $submit = $view.find('button[type="submit"]')
    , $help = $submit.next()
    , token = self.store.get(STORE.TOKEN, true)

  $view.find('.quiptree_view_header').html(err.error)
  $view.find('.message').html(err.message)
  if (err.needAuth) {
    $submit.show()
    $token.show()
    $help.show()
    if (token) $token.val(token)
  }
  else {
    $submit.hide()
    $token.hide()
    $help.hide()
  }
  $(self).trigger(EVENT.VIEW_READY)
}
function TreeView($dom, store, adapter) {
  this.$view = $dom.find('.quiptree_treeview')
  this.store = store
  this.adapter = adapter
  this.firstLoading = true
  this.$view
    .find('.quiptree_view_body')
    .on('click.jstree', '.jstree-open>a', function() {
      $.jstree.reference(this).close_node(this)
    })
    .on('click.jstree', '.jstree-closed>a', function() {
      $.jstree.reference(this).open_node(this)
    })
    .on('click', function(event) {
      var $target = $(event.target)

      // handle icon click
      if ($target.is('i.jstree-icon')) $target = $target.parent()

      if (!$target.is('a.jstree-anchor')) return
    })
}

TreeView.prototype.initTree = function(token, reload, callback) {
  var self = this
    , treeContainer = self.$view.find('.quiptree_view_body')
    , states = self.store.get(STORE.STATES)

  treeContainer.jstree({
    core : { multiple: false, themes : { responsive : false },
      data : function(folder, cb) {
        folder.id = self.firstLoading ? '#' : folder.id
        self.firstLoading = false
        self.adapter.fetchData(token, folder.id, reload, function(error, tree) {
          cb(tree)
          callback(null, error)
        })
      }
    },
    plugins : states ? ['wholerow', 'state', 'search'] : ['wholerow', 'search']
  })
}

TreeView.prototype.search = function(value) {
  var self = this
    , treeContainer = self.$view.find('.quiptree_view_body')
    , tree = treeContainer.jstree(true)

  tree.search(value)
}

TreeView.prototype.syncSelection = function() {
  var tree = this.$view.find('.quiptree_view_body').jstree(true)
    , linkId = location.pathname.substring(1)

  if (!tree) return

  data = tree.get_json(null, {no_state: true, no_data: false})

  this.searchObjViaLinkId(linkId, tree, data, function(error, nodeId) {

    if (error) return

    if (nodeId) {
      tree.deselect_all()
      tree.select_node(nodeId.id)
      if (nodeId.icon === 'tree') {
        tree.open_node(nodeId.id)
      }
    }
  })
}

TreeView.prototype.searchObjViaLinkId = function(linkId, tree, data, callback) {

  var self = this

  Object.keys(data).forEach(function(key, index) {

    obj = data[key]

    if (obj.icon === 'tree') {
      if (obj.li_attr['data-link-id'] === linkId) {
        return callback(null, obj)
      }
      else {
        if (obj.icon === 'tree') {
          self.searchObjViaLinkId(linkId, tree, obj.children, callback)
        }
      }
    }
    else {
      if (obj.a_attr['data-link-id'] === linkId) {
        return callback(null, obj)
      }
    }
  })
}

function OptionsView($dom, store) {
  var self     = this
    , $view    = $dom.find('.quiptree_optsview').submit(save)
    , $toggler = $dom.find('.quiptree_opts').click(toggle)
    , elements = $view.find('[data-store]').toArray()

  this.$view = $view

  // hide options view when sidebar is hidden
  $(document).on(EVENT.TOGGLE, function(event, visible) {
    if (!visible) toggle(false)
  })

  function toggle(visibility) {
    if (visibility !== undefined) {
      if ($view.hasClass('current') === visibility) return
      return toggle()
    }
    if ($toggler.hasClass('toggled')) {
      $toggler.removeClass('toggled')
      $(self).trigger(EVENT.VIEW_CLOSE)
    }
    else {
      eachOption(
        function($elm, key, local, value, cb) {
          if ($elm.is(':checkbox')) $elm.prop('checked', value)
          else $elm.val(value)
          cb()
        },
        function() {
          $toggler.addClass('toggled')
          $(self).trigger(EVENT.VIEW_READY)
        }
      )
    }
  }

  function save(event) {
    event.preventDefault()
    return saveOptions()

    function saveOptions() {
      var changes = {}
      eachOption(
        function($elm, key, local, value, cb) {
          var newValue = $elm.is(':checkbox') ? $elm.is(':checked') : $elm.val()
          if (value === newValue) return cb()
          changes[key] = [value, newValue]
          store.set(key, newValue, local, cb)
        },
        function() {
          toggle(false)
          if (Object.keys(changes).length) $(self).trigger(EVENT.OPTS_CHANGE, changes)
        }
      )
    }
  }

  function eachOption(processFn, completeFn) {
    parallel(elements,
      function(elm, cb) {
        var $elm  = $(elm)
          , key   = STORE[$elm.data('store')]
          , local = !!$elm.data('perhost')
        store.get(key, local, function(value) {
          processFn($elm, key, local, value, function() { cb() })
        })
      },
      completeFn
    )
  }
}
$(document).ready(function() {
  // When navigating from non-document pages (i.e. Plateform / Root) to document page
  var href, hash
  function detectLocationChange() {
    if (location.href !== href || location.hash !== hash) {
      href = location.href
      hash = location.hash
      $(document).trigger(EVENT.LOC_CHANGE, href, hash)
    }
    setTimeout(detectLocationChange, 200)
  }
  detectLocationChange()
})

function parallel(arr, iter, done) {
  var total = arr.length
  if (total === 0) return done()

  arr.forEach(function(item) {
    iter(item, finish)
  })

  function finish() {
    if (--total === 0) done()
  }
}
$(document).ready(function() {
  var store = new Storage()

  parallel(Object.keys(STORE), setDefault, loadExtension)

  function setDefault(key, cb) {
    var storeKey = STORE[key]
    var local = storeKey === STORE.TOKEN
    store.get(storeKey, local, function(val) {
      store.set(storeKey, val == null ? DEFAULTS[key] : val, local, cb)
    })
  }

  function loadExtension() {
    var $html     = $('html')
      , $document = $(document)
      , $dom      = $(TEMPLATE)
      , $sidebar  = $dom.find('.quiptree_sidebar')
      , $views    = $sidebar.find('.quiptree_view')
      , adapter   = new Quip()
      , optsView  = new OptionsView($dom, store)
      , helpPopup = new HelpPopup($dom, store)
      , treeView  = new TreeView($dom, store, adapter)
      , errorView = new ErrorView($dom, store)
      , hasError  = false

    if (adapter.canLoadExtension() === false) return

    $sidebar
      .appendTo($('body'))
      .width(parseFloat(store.get(STORE.WIDTH)))
      .resizable({ handles: 'w', minWidth: DEFAULTS.WIDTH })
      .resize(layoutChanged)

    createNavbar()
    createSearch()

    $(window).resize(function(event) { // handle zoom
      if (event.target === window) layoutChanged()
    })

    key.filter = function() { return $toggler.is(':visible') }
    key(store.get(STORE.HOTKEYS), toggleSidebarAndSave)

    ;[treeView, errorView, optsView].forEach(function(view) {
      $(view)
        .on(EVENT.VIEW_READY, function(event) {
          if (this !== optsView) $document.trigger(EVENT.REQ_END)
          showView(this.$view)
        })
        .on(EVENT.VIEW_CLOSE, function() {
          showView(hasError ? errorView.$view : treeView.$view)
        })
        .on(EVENT.OPTS_CHANGE, optionsChanged)
    })

    $document
      .on(EVENT.REQ_START, function() {
        $toggler.hide()
        $loader.show()
      })
      .on(EVENT.REQ_END, function() {
        $loader.hide()
        $toggler.show()
      })
      .on(EVENT.LOC_CHANGE, createNavbar)
      .on(EVENT.LAYOUT_CHANGE, layoutChanged)
      .on(EVENT.TOGGLE, toggledSidebar)

    return tryLoadTree()

    function createNavbar() {
      $navbar   = $('.thread-document nav')
      $navbar = ($navbar.length === 0) ? $('.folder nav') : $navbar
      if($navbar.find('.quiptree_loader').length === 0)
        $navbar.prepend('<span class="quiptree_loader button" style="display:none""></span>')
      if($navbar.find('.quiptree_toggle').length === 0)
        $navbar.prepend('<span class="quiptree_toggle button" style="display:none"></span>')
      $toggler  = $navbar.find('.quiptree_toggle')
      $loader  = $navbar.find('.quiptree_loader')
      $toggler.click(toggleSidebarAndSave)
      toggledSidebar()
      $toggler.show()
      treeView.syncSelection()
    }

    function createSearch() {
      var to = false;
      $('.quiptree_view_header input[type=text]').keyup(function () {
        if(to) { clearTimeout(to) }
        to = setTimeout(function () {
          var v = $('.quiptree_view_header input[type=text]').val()
          treeView.search(v)
        }, 250)
      })
    }

    function optionsChanged(event, changes) {
      var reload = false
      Object.keys(changes).forEach(function(storeKey) {
        var value = changes[storeKey]
        switch (storeKey) {
          case STORE.TOKEN:
            reload = true
            break
          case STORE.HOTKEYS:
            key.unbind(value[0])
            key(value[1], toggleSidebar)
            break
        }
      })
      if (reload) tryLoadTree(true)
    }

    function tryLoadTree(reload) {
      var remember = store.get(STORE.REMEMBER)
        , shown = store.get(STORE.SHOWN)
        , lazyload = store.get(STORE.LAZYLOAD)
        , token = store.get(STORE.TOKEN)

      $toggler.show()
      helpPopup.show()

      if (remember && shown) toggleSidebar(true)

      if (!lazyload || isSidebarVisible() || reload === true) {

        $document.trigger(EVENT.REQ_START)

        adapter.fetchAuthenticatedUser(token, reload, function(error, user, alreadyAuthenticated) {

          if (error) {
            error.needAuth = true
            errorView.show(error)
          }
          else if (!alreadyAuthenticated) {
            adapter.setRootFolderId(user.desktop_folder_id)
            adapter.setUserId(user.id)
            showView(treeView.$view)
            treeView.initTree(token, reload, function(error, success) {
              if (error) errorView.show(error)
              treeView.syncSelection()
            })
          }

          $document.trigger(EVENT.REQ_END)
        })
      }
    }

    function showView(view) {
      $views.removeClass('current')
      view.addClass('current')
    }

    function toggleSidebarAndSave() {
      store.set(STORE.SHOWN, !isSidebarVisible(), function() {
        toggleSidebar()
        if (isSidebarVisible()) {
          tryLoadTree()
        }
      })
    }

    function toggleSidebar(visibility) {
      if (visibility !== undefined) {
        if (isSidebarVisible() === visibility) return
        toggleSidebar()
      }
      else {
        $html.toggleClass(PREFIX)
        $document.trigger(EVENT.TOGGLE, isSidebarVisible())
      }
    }

    function toggledSidebar() {
      layoutChanged()
      $toggler.toggleClass('toggled', isSidebarVisible())
    }

    function layoutChanged() {
      var width = $sidebar.width()
      $sidebar.css('left', '')
      adapter.updateLayout(isSidebarVisible(), width)
      store.set(STORE.WIDTH, width)
    }

    function isSidebarVisible() {
      return $html.hasClass(PREFIX)
    }
  }
})
